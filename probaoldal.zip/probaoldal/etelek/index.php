<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Étel válogató</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="d-none d-sm-block">Finom magyar ételek</h1>
            </div>
        </div>
    </header>
    <nav class="container navbar navbar-expand-lg navbar-light">
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link" href="index.html">Főoldal <span class="sr-only">(current)</span></a>
                <a class="nav-link" href="index.html#leggyakoribb">A nálunk kapható ételek listája</a>
                <a class="nav-link" href="https://www.szeretlekmagyarorszag.hu/gasztro/33-tipikus-magyar-etel-ami-meghodithatja-a-vilagot/" target="_blank">Pár további magyar ínyencség</a>
            </div>
        </div>
    </nav>
    <main class="container">
        <article class="row">
            <div class="col-12">
                <h2 id="leggyakoribb">A nálunk kapható ételek listája</h2>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/almaleves.jpg" alt="Alma leves" class="img-fluid img-thumbnail">
                <h3>Almaleves</h3>
                <p class="text-center"><a href="almaleves.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/erdelyi.jpg" alt="Erdélyi raguleves" class="img-fluid img-thumbnail">
                <h3>Erdélyi raguleves</h3>
                <p class="text-center"><a href="erdelyiraguleves.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/komenymagosleves.jpg" alt="Köménymagos leves" class="img-fluid img-thumbnail">
                <h3>Köménymagos leves</h3>
                <p class="text-center"><a href="komenymagosleves.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/lencsefozelek.jpg" alt="Lencsefőzelék" class="img-fluid img-thumbnail">
                <h3>Lencsefőzelék</h3>
                <p class="text-center"><a href="lencsefozelek.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/husleves.jpg" alt="Húsleves" class="img-fluid img-thumbnail">
                <h3>Húsleves</h3>
                <p class="text-center"><a href="husleves.html" class="btn btn-outline-success">Bővebb információk</a></p>      
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/majgaluska.jpg" alt="Májgaluskaleves" class="img-fluid img-thumbnail">
                <h3>Májgaluskaleves</h3>
                <p class="text-center"><a href="majgaluska.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/porkolt.jpg" alt="Pörkölt" class="img-fluid img-thumbnail">
                <h3>Pörkölt</h3>
                <p class="text-center"><a href="porkolt.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/sztrapacska.jpg" alt="Sztrapacska" class="img-fluid img-thumbnail">
                <h3>Sztrapacska</h3>
                <p class="text-center"><a href="sztrapacska.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
            <div class="col-sm-6 col-lg-4">
                <img src="img/zeller.jpg" alt="Zellerkrémleves" class="img-fluid img-thumbnail">
                <h3>Zellerkrémleves</h3>
                <p class="text-center"><a href="zellerkremleves.html" class="btn btn-outline-success">Bővebb információk</a></p>
            </div>
        </article>
    </main>
    <script src="bootstrap/js/jquery-3.5.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</body>

</html>