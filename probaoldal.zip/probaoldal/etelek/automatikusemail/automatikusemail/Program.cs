﻿using System;
using System.Net.Mail;
namespace automatikusemail
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                mail.From = new MailAddress("fejerdi@gmail.com");
                mail.To.Add("fejerdi@gmail.com");
                mail.Subject = "Regisztráció";
                mail.Body = "Köszönjük jelentkezését. Nemsokára jelentkezünk személyre szabott ajánlatunkkal. Mentesválogató csapata.";
                
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("fejerdi@gmail.com", "AnidrejefJosefa319801");
                smtp.EnableSsl = true;

                smtp.Send(mail);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
